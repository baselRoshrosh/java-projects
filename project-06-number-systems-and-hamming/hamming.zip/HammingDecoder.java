import gdp.stdlib.*;

public class HammingDecoder {

    public static int fromHex(String s) {
        return Integer.parseInt(s, 16)  & 0xFFFF;
    }

    public static void main(String[] args) {

        while(!StdIn.isEmpty()) {
            // Einlesen der Eingabewerte
            int m1 = fromHex(StdIn.readString());
            if (m1 == 0xFFFF) break;
            int m2 = fromHex(StdIn.readString());
            int m3 = fromHex(StdIn.readString());
            int m4 = fromHex(StdIn.readString());
            int p1 = fromHex(StdIn.readString());
            int p2 = fromHex(StdIn.readString());
            int p3 = fromHex(StdIn.readString());

            // Prüfung der Paritätsbits
            int c1 = p1 ^ m1 ^ m2 ^ m4;
            int c2 = p2 ^ m1 ^ m3 ^ m4;
            int c3 = p3 ^ m2 ^ m3 ^ m4;

            // Korrektur der Bits (falls notwendig)
            if (c1 + c2 + c3 == 3) m4 = 1 ^ m4;
            else if (c1 + c2 == 2) m1 = 1 ^ m1;
            else if (c1 + c3 == 2) m2 = 1 ^ m2;
            else if (c2 + c3 == 2) m3 = 1 ^ m3;

            // Ausgabe der korrigierten Bits (entsprechend der Ausgabe von Toy)
            System.out.println("000" + m1 + "\n000" + m2 + "\n000" + m3 + "\n000" + m4);

            // Ausgabe der korrigierten Bits in einer besser lesbaren Formatierung
            // (Zur Aktivierung die Ausgabe in Zeile 34 auskommentieren und die nachfolgende
            //  Zeile stattdessen verwenden)
            //System.out.println(m1 + " " + m2 + " " + m3 + " " + m4);
             
        }
    }
}
