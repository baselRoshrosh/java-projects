import gdp.stdlib.*;
 
public class HammingEncoder {

    public static int fromHex(String s) {
        return Integer.parseInt(s, 16)  & 0xFFFF;
    }

    public static void main(String[] args) {
        while(!StdIn.isEmpty()) {
            // Einlesen der Eingabewerte
            int m1 = fromHex(StdIn.readString());
            if (m1 == 0xFFFF) break;
            int m2 = fromHex(StdIn.readString());
            int m3 = fromHex(StdIn.readString());
            int m4 = fromHex(StdIn.readString());

            // Berechnung der Paritätsbits
            int p1 = m1 ^ m2 ^ m4;
            int p2 = m1 ^ m3 ^ m4;
            int p3 = m2 ^ m3 ^ m4;

            // Ausgabe der kodierten Nachricht entsprechend der Ausgabe der Toy-Machine
            System.out.println("000" + m1 + "\n000" + m2 + "\n000" + m3 + "\n000" + m4);
            System.out.println("000" + p1 + "\n000" + p2 + "\n000" + p3);
            
            // Ausgabe der kodierten Nachricht in besser lesbarer Form
            // (Zur Aktivierung obere Ausgabe auskommentieren und stattdessen
            // folgende Zeilen verwenden)
            //System.out.print(m1 + " " + m2 + " " + m3 + " " + m4 + " ");
            //System.out.print(p1 + " " + p2 + " " + p3);
            //System.out.println();
        }
    }
}
